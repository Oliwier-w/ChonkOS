# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_seal_global_optspecs
    string join \n json store= h/help V/version
end

function __fish_seal_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_seal_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_seal_using_subcommand
    set -l cmd (__fish_seal_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c seal -n "__fish_seal_needs_command" -l store -r -F
complete -c seal -n "__fish_seal_needs_command" -l json
complete -c seal -n "__fish_seal_needs_command" -s h -l help -d 'Print help'
complete -c seal -n "__fish_seal_needs_command" -s V -l version -d 'Print version'
complete -c seal -n "__fish_seal_needs_command" -f -a "mark"
complete -c seal -n "__fish_seal_needs_command" -f -a "list"
complete -c seal -n "__fish_seal_needs_command" -f -a "diff"
complete -c seal -n "__fish_seal_needs_command" -f -a "restore"
complete -c seal -n "__fish_seal_needs_command" -f -a "export"
complete -c seal -n "__fish_seal_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c seal -n "__fish_seal_using_subcommand mark" -l store -r -F
complete -c seal -n "__fish_seal_using_subcommand mark" -l json
complete -c seal -n "__fish_seal_using_subcommand mark" -s h -l help -d 'Print help'
complete -c seal -n "__fish_seal_using_subcommand list" -l store -r -F
complete -c seal -n "__fish_seal_using_subcommand list" -l json
complete -c seal -n "__fish_seal_using_subcommand list" -s h -l help -d 'Print help'
complete -c seal -n "__fish_seal_using_subcommand diff" -l store -r -F
complete -c seal -n "__fish_seal_using_subcommand diff" -l json
complete -c seal -n "__fish_seal_using_subcommand diff" -s h -l help -d 'Print help'
complete -c seal -n "__fish_seal_using_subcommand restore" -l store -r -F
complete -c seal -n "__fish_seal_using_subcommand restore" -l dry-run
complete -c seal -n "__fish_seal_using_subcommand restore" -l json
complete -c seal -n "__fish_seal_using_subcommand restore" -s h -l help -d 'Print help'
complete -c seal -n "__fish_seal_using_subcommand export" -l store -r -F
complete -c seal -n "__fish_seal_using_subcommand export" -l json
complete -c seal -n "__fish_seal_using_subcommand export" -s h -l help -d 'Print help'
complete -c seal -n "__fish_seal_using_subcommand help; and not __fish_seen_subcommand_from mark list diff restore export help" -f -a "mark"
complete -c seal -n "__fish_seal_using_subcommand help; and not __fish_seen_subcommand_from mark list diff restore export help" -f -a "list"
complete -c seal -n "__fish_seal_using_subcommand help; and not __fish_seen_subcommand_from mark list diff restore export help" -f -a "diff"
complete -c seal -n "__fish_seal_using_subcommand help; and not __fish_seen_subcommand_from mark list diff restore export help" -f -a "restore"
complete -c seal -n "__fish_seal_using_subcommand help; and not __fish_seen_subcommand_from mark list diff restore export help" -f -a "export"
complete -c seal -n "__fish_seal_using_subcommand help; and not __fish_seen_subcommand_from mark list diff restore export help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
