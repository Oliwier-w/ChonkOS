# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_chonk_global_optspecs
    string join \n json h/help V/version
end

function __fish_chonk_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_chonk_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_chonk_using_subcommand
    set -l cmd (__fish_chonk_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c chonk -n "__fish_chonk_needs_command" -l json
complete -c chonk -n "__fish_chonk_needs_command" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_needs_command" -s V -l version -d 'Print version'
complete -c chonk -n "__fish_chonk_needs_command" -f -a "doctor"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "apply"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "mode"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "mood"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "card" -d 'Show hardware health'
complete -c chonk -n "__fish_chonk_needs_command" -f -a "try" -d 'Snapshot system configuration, run a command, and show changes'
complete -c chonk -n "__fish_chonk_needs_command" -f -a "profile" -d 'Show or change the active ChonkOS profile'
complete -c chonk -n "__fish_chonk_needs_command" -f -a "update"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "clean"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "docs"
complete -c chonk -n "__fish_chonk_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c chonk -n "__fish_chonk_using_subcommand doctor" -l json
complete -c chonk -n "__fish_chonk_using_subcommand doctor" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand apply" -l config -r -F
complete -c chonk -n "__fish_chonk_using_subcommand apply" -l dry-run
complete -c chonk -n "__fish_chonk_using_subcommand apply" -l json
complete -c chonk -n "__fish_chonk_using_subcommand apply" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand mode" -l dark
complete -c chonk -n "__fish_chonk_using_subcommand mode" -l dry-run
complete -c chonk -n "__fish_chonk_using_subcommand mode" -l json
complete -c chonk -n "__fish_chonk_using_subcommand mode" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand mood" -l waybar
complete -c chonk -n "__fish_chonk_using_subcommand mood" -l json
complete -c chonk -n "__fish_chonk_using_subcommand mood" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand card" -l plain
complete -c chonk -n "__fish_chonk_using_subcommand card" -l tty
complete -c chonk -n "__fish_chonk_using_subcommand card" -l json
complete -c chonk -n "__fish_chonk_using_subcommand card" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand try" -l label -r
complete -c chonk -n "__fish_chonk_using_subcommand try" -l json
complete -c chonk -n "__fish_chonk_using_subcommand try" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand profile" -l dark -d 'Run nap dark on when selecting homelab'
complete -c chonk -n "__fish_chonk_using_subcommand profile" -l json
complete -c chonk -n "__fish_chonk_using_subcommand profile" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand update" -l yes
complete -c chonk -n "__fish_chonk_using_subcommand update" -l json
complete -c chonk -n "__fish_chonk_using_subcommand update" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand clean" -l dry-run
complete -c chonk -n "__fish_chonk_using_subcommand clean" -l dev
complete -c chonk -n "__fish_chonk_using_subcommand clean" -l json
complete -c chonk -n "__fish_chonk_using_subcommand clean" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand docs" -l json
complete -c chonk -n "__fish_chonk_using_subcommand docs" -s h -l help -d 'Print help'
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "doctor"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "apply"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "mode"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "mood"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "card" -d 'Show hardware health'
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "try" -d 'Snapshot system configuration, run a command, and show changes'
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "profile" -d 'Show or change the active ChonkOS profile'
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "update"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "clean"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "docs"
complete -c chonk -n "__fish_chonk_using_subcommand help; and not __fish_seen_subcommand_from doctor apply mode mood card try profile update clean docs help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
