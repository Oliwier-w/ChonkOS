# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_scale_global_optspecs
    string join \n json h/help V/version
end

function __fish_scale_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_scale_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_scale_using_subcommand
    set -l cmd (__fish_scale_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c scale -n "__fish_scale_needs_command" -l json
complete -c scale -n "__fish_scale_needs_command" -s h -l help -d 'Print help'
complete -c scale -n "__fish_scale_needs_command" -s V -l version -d 'Print version'
complete -c scale -n "__fish_scale_needs_command" -f -a "ram"
complete -c scale -n "__fish_scale_needs_command" -f -a "boot"
complete -c scale -n "__fish_scale_needs_command" -f -a "pkg"
complete -c scale -n "__fish_scale_needs_command" -f -a "dir"
complete -c scale -n "__fish_scale_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c scale -n "__fish_scale_using_subcommand ram" -l top -r
complete -c scale -n "__fish_scale_using_subcommand ram" -l json
complete -c scale -n "__fish_scale_using_subcommand ram" -s h -l help -d 'Print help'
complete -c scale -n "__fish_scale_using_subcommand boot" -l top -r
complete -c scale -n "__fish_scale_using_subcommand boot" -l json
complete -c scale -n "__fish_scale_using_subcommand boot" -s h -l help -d 'Print help'
complete -c scale -n "__fish_scale_using_subcommand pkg" -l top -r
complete -c scale -n "__fish_scale_using_subcommand pkg" -l json
complete -c scale -n "__fish_scale_using_subcommand pkg" -s h -l help -d 'Print help'
complete -c scale -n "__fish_scale_using_subcommand dir" -l top -r
complete -c scale -n "__fish_scale_using_subcommand dir" -l json
complete -c scale -n "__fish_scale_using_subcommand dir" -s h -l help -d 'Print help'
complete -c scale -n "__fish_scale_using_subcommand help; and not __fish_seen_subcommand_from ram boot pkg dir help" -f -a "ram"
complete -c scale -n "__fish_scale_using_subcommand help; and not __fish_seen_subcommand_from ram boot pkg dir help" -f -a "boot"
complete -c scale -n "__fish_scale_using_subcommand help; and not __fish_seen_subcommand_from ram boot pkg dir help" -f -a "pkg"
complete -c scale -n "__fish_scale_using_subcommand help; and not __fish_seen_subcommand_from ram boot pkg dir help" -f -a "dir"
complete -c scale -n "__fish_scale_using_subcommand help; and not __fish_seen_subcommand_from ram boot pkg dir help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
