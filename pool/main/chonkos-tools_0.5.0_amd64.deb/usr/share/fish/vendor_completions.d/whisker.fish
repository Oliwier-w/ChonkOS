# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_whisker_global_optspecs
    string join \n json h/help V/version
end

function __fish_whisker_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_whisker_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_whisker_using_subcommand
    set -l cmd (__fish_whisker_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c whisker -n "__fish_whisker_needs_command" -l json
complete -c whisker -n "__fish_whisker_needs_command" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_needs_command" -s V -l version -d 'Print version'
complete -c whisker -n "__fish_whisker_needs_command" -f -a "lease"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "baseline"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "drift"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "ports"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "kill"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "net"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "watch"
complete -c whisker -n "__fish_whisker_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c whisker -n "__fish_whisker_using_subcommand lease; and not __fish_seen_subcommand_from add list revoke help" -l json
complete -c whisker -n "__fish_whisker_using_subcommand lease; and not __fish_seen_subcommand_from add list revoke help" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand lease; and not __fish_seen_subcommand_from add list revoke help" -f -a "add"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and not __fish_seen_subcommand_from add list revoke help" -f -a "list"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and not __fish_seen_subcommand_from add list revoke help" -f -a "revoke"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and not __fish_seen_subcommand_from add list revoke help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from add" -l for -r
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from add" -l proto -r -f -a "tcp\t''
udp\t''"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from add" -l json
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from list" -l json
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from revoke" -l proto -r -f -a "tcp\t''
udp\t''"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from revoke" -l json
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from revoke" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from help" -f -a "add"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from help" -f -a "list"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from help" -f -a "revoke"
complete -c whisker -n "__fish_whisker_using_subcommand lease; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c whisker -n "__fish_whisker_using_subcommand baseline" -l save
complete -c whisker -n "__fish_whisker_using_subcommand baseline" -l json
complete -c whisker -n "__fish_whisker_using_subcommand baseline" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand drift" -l json
complete -c whisker -n "__fish_whisker_using_subcommand drift" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand ports" -l all
complete -c whisker -n "__fish_whisker_using_subcommand ports" -l json
complete -c whisker -n "__fish_whisker_using_subcommand ports" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand kill" -l force
complete -c whisker -n "__fish_whisker_using_subcommand kill" -l yes
complete -c whisker -n "__fish_whisker_using_subcommand kill" -l json
complete -c whisker -n "__fish_whisker_using_subcommand kill" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand net" -l json
complete -c whisker -n "__fish_whisker_using_subcommand net" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand watch" -l timeout -r
complete -c whisker -n "__fish_whisker_using_subcommand watch" -l interval -r
complete -c whisker -n "__fish_whisker_using_subcommand watch" -l json
complete -c whisker -n "__fish_whisker_using_subcommand watch" -s h -l help -d 'Print help'
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "lease"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "baseline"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "drift"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "ports"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "kill"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "net"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "watch"
complete -c whisker -n "__fish_whisker_using_subcommand help; and not __fish_seen_subcommand_from lease baseline drift ports kill net watch help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c whisker -n "__fish_whisker_using_subcommand help; and __fish_seen_subcommand_from lease" -f -a "add"
complete -c whisker -n "__fish_whisker_using_subcommand help; and __fish_seen_subcommand_from lease" -f -a "list"
complete -c whisker -n "__fish_whisker_using_subcommand help; and __fish_seen_subcommand_from lease" -f -a "revoke"
