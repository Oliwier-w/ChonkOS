# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_nap_global_optspecs
    string join \n json h/help V/version
end

function __fish_nap_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_nap_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_nap_using_subcommand
    set -l cmd (__fish_nap_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c nap -n "__fish_nap_needs_command" -l json
complete -c nap -n "__fish_nap_needs_command" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_needs_command" -s V -l version -d 'Print version'
complete -c nap -n "__fish_nap_needs_command" -f -a "status"
complete -c nap -n "__fish_nap_needs_command" -f -a "dive" -d 'Manage battery-triggered shutdown'
complete -c nap -n "__fish_nap_needs_command" -f -a "guard" -d 'Manage the hardware battery charge limit'
complete -c nap -n "__fish_nap_needs_command" -f -a "dark" -d 'Switch the built-in panel backlight off or on'
complete -c nap -n "__fish_nap_needs_command" -f -a "stay"
complete -c nap -n "__fish_nap_needs_command" -f -a "lid"
complete -c nap -n "__fish_nap_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c nap -n "__fish_nap_using_subcommand status" -l json
complete -c nap -n "__fish_nap_using_subcommand status" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -l event
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -l dry-run
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -l json
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -f -a "enable"
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -f -a "disable"
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -f -a "status"
complete -c nap -n "__fish_nap_using_subcommand dive; and not __fish_seen_subcommand_from enable disable status help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from enable" -l threshold -r
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from enable" -l services -r
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from enable" -l json
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from enable" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from disable" -l json
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from disable" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from status" -l json
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from help" -f -a "enable"
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from help" -f -a "disable"
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from help" -f -a "status"
complete -c nap -n "__fish_nap_using_subcommand dive; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c nap -n "__fish_nap_using_subcommand guard; and not __fish_seen_subcommand_from enable disable status help" -l json
complete -c nap -n "__fish_nap_using_subcommand guard; and not __fish_seen_subcommand_from enable disable status help" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand guard; and not __fish_seen_subcommand_from enable disable status help" -f -a "enable"
complete -c nap -n "__fish_nap_using_subcommand guard; and not __fish_seen_subcommand_from enable disable status help" -f -a "disable"
complete -c nap -n "__fish_nap_using_subcommand guard; and not __fish_seen_subcommand_from enable disable status help" -f -a "status"
complete -c nap -n "__fish_nap_using_subcommand guard; and not __fish_seen_subcommand_from enable disable status help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from enable" -l limit -r -f -a "60\t''
80\t''"
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from enable" -l json
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from enable" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from disable" -l json
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from disable" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from status" -l json
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from help" -f -a "enable"
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from help" -f -a "disable"
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from help" -f -a "status"
complete -c nap -n "__fish_nap_using_subcommand guard; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c nap -n "__fish_nap_using_subcommand dark" -l json
complete -c nap -n "__fish_nap_using_subcommand dark" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand stay" -l json
complete -c nap -n "__fish_nap_using_subcommand stay" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand lid" -l json
complete -c nap -n "__fish_nap_using_subcommand lid" -s h -l help -d 'Print help'
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "status"
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "dive" -d 'Manage battery-triggered shutdown'
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "guard" -d 'Manage the hardware battery charge limit'
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "dark" -d 'Switch the built-in panel backlight off or on'
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "stay"
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "lid"
complete -c nap -n "__fish_nap_using_subcommand help; and not __fish_seen_subcommand_from status dive guard dark stay lid help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c nap -n "__fish_nap_using_subcommand help; and __fish_seen_subcommand_from dive" -f -a "enable"
complete -c nap -n "__fish_nap_using_subcommand help; and __fish_seen_subcommand_from dive" -f -a "disable"
complete -c nap -n "__fish_nap_using_subcommand help; and __fish_seen_subcommand_from dive" -f -a "status"
complete -c nap -n "__fish_nap_using_subcommand help; and __fish_seen_subcommand_from guard" -f -a "enable"
complete -c nap -n "__fish_nap_using_subcommand help; and __fish_seen_subcommand_from guard" -f -a "disable"
complete -c nap -n "__fish_nap_using_subcommand help; and __fish_seen_subcommand_from guard" -f -a "status"
